package com.mrcrayfish.furniturece;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class CESoundEvents
{
	public static SoundEvent bear;

	public static void init()
	{
		ResourceLocation loc = new ResourceLocation(Reference.MOD_ID, "roar");
		bear = new SoundEvent(loc).setRegistryName(loc);
	}
}
