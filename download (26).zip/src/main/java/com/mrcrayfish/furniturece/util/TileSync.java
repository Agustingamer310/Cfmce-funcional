package com.mrcrayfish.furniturece.util;

import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class TileSync
{
	/** Marks the tile entity dirty (saved) and sends its data to the clients. */
	public static void sync(TileEntity te)
	{
		te.markDirty();
		World world = te.getWorld();
		if (world != null)
		{
			IBlockState state = world.getBlockState(te.getPos());
			world.notifyBlockUpdate(te.getPos(), state, state, 3);
		}
	}
}
