package com.mrcrayfish.furniturece;

import com.mrcrayfish.furniturece.entity.EntitySittableBlock;
import com.mrcrayfish.furniturece.gui.GuiHandler;
import com.mrcrayfish.furniturece.network.PacketHandler;
import com.mrcrayfish.furniturece.proxy.IFurnitureProxy;
import com.mrcrayfish.furniturece.tileentity.TileEntityAirVent;
import com.mrcrayfish.furniturece.tileentity.TileEntityAquarium;
import com.mrcrayfish.furniturece.tileentity.TileEntityBookShelf;
import com.mrcrayfish.furniturece.tileentity.TileEntityWaterCooler;
import com.mrcrayfish.furniturece.tileentity.TileEntityBlackBoard;
import com.mrcrayfish.furniturece.tileentity.TileEntityBottle;
import com.mrcrayfish.furniturece.tileentity.TileEntityCanvas;
import com.mrcrayfish.furniturece.tileentity.TileEntityOfficeChair;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = Reference.MOD_ID, name = Reference.NAME, version = Reference.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class MrCrayfishFurnitureModCE
{
	@Instance(Reference.MOD_ID)
	public static MrCrayfishFurnitureModCE instance;

	@SidedProxy(clientSide = Reference.CLIENT_PROXY_CLASS, serverSide = Reference.SERVER_PROXY_CLASS)
	public static IFurnitureProxy proxy;

	public static CreativeTabs tabFurniture = new FurnitureTab("tabFurnitureCE");

	@EventHandler
	public void preInit(FMLPreInitializationEvent event)
	{
		/** Blocks, items and sounds are registered in init.RegistryHandler */
		proxy.preInit();

		/** Packet Registering */
		PacketHandler.init();

		/** TileEntity Registering */
		GameRegistry.registerTileEntity(TileEntityAquarium.class, new ResourceLocation(Reference.MOD_ID, "aquarium"));
		GameRegistry.registerTileEntity(TileEntityCanvas.class, new ResourceLocation(Reference.MOD_ID, "canvas"));
		GameRegistry.registerTileEntity(TileEntityBottle.class, new ResourceLocation(Reference.MOD_ID, "bottle"));
		GameRegistry.registerTileEntity(TileEntityOfficeChair.class, new ResourceLocation(Reference.MOD_ID, "office_chair"));
		GameRegistry.registerTileEntity(TileEntityBlackBoard.class, new ResourceLocation(Reference.MOD_ID, "black_board"));

		GameRegistry.registerTileEntity(TileEntityAirVent.class, new ResourceLocation(Reference.MOD_ID, "air_vent"));
		GameRegistry.registerTileEntity(TileEntityBookShelf.class, new ResourceLocation(Reference.MOD_ID, "book_shelf"));
		GameRegistry.registerTileEntity(TileEntityWaterCooler.class, new ResourceLocation(Reference.MOD_ID, "water_cooler"));

		/** Entity Registering */
		EntityRegistry.registerModEntity(new ResourceLocation(Reference.MOD_ID, "sittable_block"), EntitySittableBlock.class, "sittable_block", 0, this, 80, 1, false);
	}

	@EventHandler
	public void init(FMLInitializationEvent event)
	{
		proxy.init();
		NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());
	}

	@EventHandler
	public void postInit(FMLPostInitializationEvent event)
	{
		proxy.postInit();
	}
}
