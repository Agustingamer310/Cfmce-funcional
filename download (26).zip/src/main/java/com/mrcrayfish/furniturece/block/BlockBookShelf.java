package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import com.mrcrayfish.furniturece.MrCrayfishFurnitureModCE;
import com.mrcrayfish.furniturece.gui.GuiBasicInventory;
import com.mrcrayfish.furniturece.tileentity.TileEntityBookShelf;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockBookShelf extends BlockFurnitureOffice implements ITileEntityProvider
{
	public BlockBookShelf(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("book_shelf");
		setRegistryName(Reference.MOD_ID, "book_shelf");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return com.mrcrayfish.furniturece.util.CollisionHelper.rotated(metaOf(state), 7 * 0.0625F, 0F, 0F, 1F, 14 * 0.0625F, 1F);
	}

	public static final PropertyInteger BOOKS = PropertyInteger.create("books", 0, 5);

	@Override
	public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
	{
		if (hand != EnumHand.MAIN_HAND) return false;
		playerIn.openGui(MrCrayfishFurnitureModCE.instance, GuiBasicInventory.ID, worldIn, pos.getX(), pos.getY(), pos.getZ());
		return true;
	}

	@Override
	public IBlockState getActualState(IBlockState state, IBlockAccess worldIn, BlockPos pos)
	{
		TileEntity tileEntity = worldIn.getTileEntity(pos);
		if (tileEntity instanceof TileEntityBookShelf)
		{
			return state.withProperty(BOOKS, ((TileEntityBookShelf) tileEntity).getBookCount());
		}
		return state;
	}

	@Override
	public void breakBlock(World worldIn, BlockPos pos, IBlockState state)
	{
		TileEntity tileEntity = worldIn.getTileEntity(pos);
		if (tileEntity instanceof TileEntityBookShelf)
		{
			net.minecraft.inventory.InventoryHelper.dropInventoryItems(worldIn, pos, (TileEntityBookShelf) tileEntity);
		}
		super.breakBlock(worldIn, pos, state);
	}

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta)
	{
		return new TileEntityBookShelf();
	}

	@Override
	protected BlockStateContainer createBlockState()
	{
		return new BlockStateContainer(this, FACING, BOOKS);
	}

	@Override
	public String getAuthorName()
	{
		return "NEEP";
	}

	@Override
	public int getAuthorID()
	{
		return 991;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
