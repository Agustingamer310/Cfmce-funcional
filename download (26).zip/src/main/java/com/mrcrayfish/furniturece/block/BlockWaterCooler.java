package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import com.mrcrayfish.furniturece.tileentity.TileEntityWaterCooler;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockWaterCooler extends BlockFurnitureOffice implements ITileEntityProvider
{
	public BlockWaterCooler(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("cooler");
		setRegistryName(Reference.MOD_ID, "cooler");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return new AxisAlignedBB(2 * 0.0625F, 0F, 2 * 0.0625F, 14 * 0.0625F, 20 * 0.0625F, 14 * 0.0625F);
	}

	@Override
	protected AxisAlignedBB getCollisionBounds(IBlockState state)
	{
		return new AxisAlignedBB(3 * 0.0625F, 0F, 3 * 0.0625F, 13 * 0.0625F, 20 * 0.0625F, 13 * 0.0625F);
	}

	@Override
	public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
	{
		if (hand != EnumHand.MAIN_HAND) return false;
		if (!worldIn.isRemote)
		{
			ItemStack current = playerIn.getHeldItem(hand);
			if (!current.isEmpty())
			{
				TileEntity tileEntity = worldIn.getTileEntity(pos);
				if (tileEntity instanceof TileEntityWaterCooler)
				{
					TileEntityWaterCooler cooler = (TileEntityWaterCooler) tileEntity;
					if (current.getItem() == Items.BUCKET)
					{
						if (cooler.removeWater())
						{
							playerIn.setHeldItem(hand, new ItemStack(Items.WATER_BUCKET));
						}
					}
					else if (current.getItem() == Items.WATER_BUCKET)
					{
						if (cooler.addWater())
						{
							playerIn.setHeldItem(hand, new ItemStack(Items.BUCKET));
						}
					}
				}
			}
		}
		return true;
	}

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta)
	{
		return new TileEntityWaterCooler();
	}

	@Override
	public String getAuthorName()
	{
		return "JustACoolGuy";
	}

	@Override
	public int getAuthorID()
	{
		return 19;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
