package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class Block3DPrinter extends BlockFurnitureOffice
{
	public Block3DPrinter(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("three_dimension_printer");
		setRegistryName(Reference.MOD_ID, "three_dimension_printer");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return new AxisAlignedBB(0F, 0F, 0F, 1F, 13 * 0.0625F, 1F);
	}

	@Override
	public String getAuthorName()
	{
		return "LeoChima";
	}

	@Override
	public int getAuthorID()
	{
		return 958;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
