package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockCoffeeMachine extends BlockFurnitureOffice
{
	public BlockCoffeeMachine(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("coffee_machine");
		setRegistryName(Reference.MOD_ID, "coffee_machine");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return new AxisAlignedBB(0F, 0F, 0F, 1F, 24 * 0.0625F, 1F);
	}

	@Override
	public String getAuthorName()
	{
		return "Zekeeh";
	}

	@Override
	public int getAuthorID()
	{
		return 646;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
