package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockCorkBoard extends BlockFurnitureOffice
{
	public BlockCorkBoard(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("cork_board");
		setRegistryName(Reference.MOD_ID, "cork_board");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return com.mrcrayfish.furniturece.util.CollisionHelper.rotated(metaOf(state), 14 * 0.0625F, 0F, 0F, 1F, 1F, 1F);
	}

	@Override
	public String getAuthorName()
	{
		return "noah2214";
	}

	@Override
	public int getAuthorID()
	{
		return 1190;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
