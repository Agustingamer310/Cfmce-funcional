package com.mrcrayfish.furniturece;

public class Reference
{
	public static final String MOD_ID = "cfmce";
	public static final String NAME = "MrCrayfish's Furniture Mod: Community Edition";
	public static final String VERSION = "1.0.1-1.12.2";
	public static final String CLIENT_PROXY_CLASS = "com.mrcrayfish.furniturece.proxy.ClientProxy";
	public static final String SERVER_PROXY_CLASS = "com.mrcrayfish.furniturece.proxy.ServerProxy";
	
	public static final String THEME_BASIC = "Basics";
	public static final String THEME_OFFICE = "Office";
}
