package com.mrcrayfish.furniturece.init;

import com.mrcrayfish.furniturece.Reference;
import com.mrcrayfish.furniturece.item.ItemEasterEgg;
import com.mrcrayfish.furniturece.item.ItemInfoPencil;

import net.minecraft.item.Item;
import net.minecraftforge.registries.IForgeRegistry;

public class FurnitureItems
{
	public static Item info_pencil, easter_egg;

	public static void init()
	{
		info_pencil = new ItemInfoPencil().setUnlocalizedName("item_info_pencil").setRegistryName(Reference.MOD_ID, "item_info_pencil");
		easter_egg = new ItemEasterEgg().setUnlocalizedName("item_easter_egg").setRegistryName(Reference.MOD_ID, "item_easter_egg");
	}

	public static void register(IForgeRegistry<Item> registry)
	{
		registry.register(info_pencil);
		registry.register(easter_egg);
	}
}
